"use client";
// src/app/(admin)/admin/quiz-builder/page.tsx
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useRouter, useSearchParams } from "next/navigation";
import Link from "next/link";
import { fetchWithAuth } from "@/hooks/useAuth";
import { useToast } from "@/store/uiStore";
import type { QuestionForm, ChoiceForm } from "@/types";

const blankChoice = (): ChoiceForm => ({ text: "", imageUrl: "", isCorrect: false });
const blankQuestion = (): QuestionForm => ({
  text: "", imageUrl: "", type: "MULTIPLE_CHOICE",
  choices: [blankChoice(), blankChoice(), blankChoice(), blankChoice()],
});

export default function QuizBuilderPage() {
  const router       = useRouter();
  const searchParams = useSearchParams();
  const toast        = useToast();
  const qc           = useQueryClient();

  const lectureId = searchParams.get("lectureId") ?? "";
  const type      = (searchParams.get("type") ?? "quiz") as "quiz" | "homework";

  const [quizTitle,  setQuizTitle]  = useState("");
  const [timeLimit,  setTimeLimit]  = useState<string>("");
  const [questions,  setQuestions]  = useState<QuestionForm[]>([blankQuestion()]);

  // ── Mutations ──
  const createQuiz = useMutation({
    mutationFn: () =>
      fetchWithAuth("/api/quizzes", {
        method: "POST",
        body: JSON.stringify({
          lectureId, title: quizTitle,
          timeLimit: timeLimit ? parseInt(timeLimit) : null,
          questions,
        }),
      }),
    onSuccess: (res) => {
      if (res.success) {
        toast.success("✅ تم إنشاء الاختبار");
        qc.invalidateQueries({ queryKey: ["admin-lecture", lectureId] });
        router.push(`/admin/lectures/${lectureId}`);
      } else toast.error(res.error ?? "فشل الإنشاء");
    },
  });

  const createHomework = useMutation({
    mutationFn: () =>
      fetchWithAuth("/api/homework", {
        method: "POST",
        body: JSON.stringify({ lectureId, title: quizTitle, questions }),
      }),
    onSuccess: (res) => {
      if (res.success) {
        toast.success("✅ تم إنشاء الواجب");
        qc.invalidateQueries({ queryKey: ["admin-lecture", lectureId] });
        router.push(`/admin/lectures/${lectureId}`);
      } else toast.error(res.error ?? "فشل الإنشاء");
    },
  });

  // ── Question helpers ──
  const addQuestion = () => setQuestions((q) => [...q, blankQuestion()]);
  const removeQuestion = (qi: number) => setQuestions((q) => q.filter((_, i) => i !== qi));

  const updateQuestion = (qi: number, field: keyof QuestionForm, value: unknown) =>
    setQuestions((prev) => prev.map((q, i) => i === qi ? { ...q, [field]: value } : q));

  const updateChoice = (qi: number, ci: number, field: keyof ChoiceForm, value: unknown) =>
    setQuestions((prev) => prev.map((q, i) =>
      i !== qi ? q : {
        ...q,
        choices: q.choices.map((c, j) => j === ci ? { ...c, [field]: value } : c),
      }
    ));

  const setCorrect = (qi: number, ci: number) =>
    setQuestions((prev) => prev.map((q, i) =>
      i !== qi ? q : {
        ...q,
        choices: q.choices.map((c, j) => ({ ...c, isCorrect: j === ci })),
      }
    ));

  const addChoice = (qi: number) =>
    setQuestions((prev) => prev.map((q, i) =>
      i === qi ? { ...q, choices: [...q.choices, blankChoice()] } : q
    ));

  const removeChoice = (qi: number, ci: number) =>
    setQuestions((prev) => prev.map((q, i) =>
      i !== qi ? q : { ...q, choices: q.choices.filter((_, j) => j !== ci) }
    ));

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!quizTitle.trim()) { toast.error("أدخل عنوان " + (type === "quiz" ? "الاختبار" : "الواجب")); return; }
    if (!lectureId)        { toast.error("lectureId مفقود"); return; }
    const invalid = questions.find((q) => !q.text && !q.imageUrl);
    if (invalid) { toast.error("كل سؤال يجب أن يحتوي على نص أو صورة"); return; }
    const noCorrect = questions.find((q) => type === "quiz" && !q.choices.some((c) => c.isCorrect));
    if (noCorrect) { toast.error("حدد الإجابة الصحيحة لكل سؤال"); return; }
    type === "quiz" ? createQuiz.mutate() : createHomework.mutate();
  };

  const isPending = createQuiz.isPending || createHomework.isPending;

  const fieldStyle: React.CSSProperties = {
    padding: "10px 12px", borderRadius: 10, border: "1.5px solid rgba(201,168,76,0.25)",
    background: "#FAFAF8", color: "#1A1208", fontFamily: "Cairo,sans-serif",
    fontSize: 13, outline: "none", direction: "rtl", transition: "border-color 0.2s",
  };

  return (
    <div style={{ direction: "rtl" }}>
      {/* Header */}
      <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} className="flex items-center gap-4 mb-8">
        <Link href={lectureId ? `/admin/lectures/${lectureId}` : "/admin/lectures"}
          style={{ color: "#C9A84C", fontFamily: "Cairo,sans-serif", fontSize: 13, textDecoration: "none" }}>
          ← عودة للمحاضرة
        </Link>
        <h1 style={{ fontFamily: "Amiri,serif", color: "#1A1208", fontSize: 28 }}>
          {type === "quiz" ? "🧪 إنشاء اختبار" : "📋 إنشاء واجب"}
        </h1>
      </motion.div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Title + time limit */}
        <div className="rounded-2xl p-6" style={{ background: "#fff", border: "1px solid rgba(201,168,76,0.15)", boxShadow: "0 2px 12px rgba(26,18,8,0.04)" }}>
          <div className="flex gap-4 flex-wrap">
            <div style={{ flex: 2, minWidth: 200 }}>
              <label style={{ fontFamily: "Cairo,sans-serif", color: "#4A3F2A", fontSize: 13, marginBottom: 5, display: "block", fontWeight: 600 }}>
                {type === "quiz" ? "عنوان الاختبار *" : "عنوان الواجب *"}
              </label>
              <input value={quizTitle} onChange={(e) => setQuizTitle(e.target.value)}
                placeholder={type === "quiz" ? "مثال: اختبار الدرس الأول" : "مثال: واجب المبتدأ والخبر"}
                style={{ ...fieldStyle, width: "100%" }}
                onFocus={(e) => (e.target.style.borderColor = "rgba(201,168,76,0.6)")}
                onBlur={(e)  => (e.target.style.borderColor = "rgba(201,168,76,0.25)")} />
            </div>
            {type === "quiz" && (
              <div style={{ flex: 1, minWidth: 140 }}>
                <label style={{ fontFamily: "Cairo,sans-serif", color: "#4A3F2A", fontSize: 13, marginBottom: 5, display: "block", fontWeight: 600 }}>
                  الوقت (دقيقة) — اختياري
                </label>
                <input type="number" min="1" value={timeLimit} onChange={(e) => setTimeLimit(e.target.value)}
                  placeholder="بلا حد"
                  style={{ ...fieldStyle, width: "100%", direction: "ltr" }}
                  onFocus={(e) => (e.target.style.borderColor = "rgba(201,168,76,0.6)")}
                  onBlur={(e)  => (e.target.style.borderColor = "rgba(201,168,76,0.25)")} />
              </div>
            )}
          </div>
        </div>

        {/* Questions */}
        <AnimatePresence>
          {questions.map((q, qi) => (
            <motion.div
              key={qi}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.97 }}
              transition={{ duration: 0.25 }}
              className="rounded-2xl p-6"
              style={{ background: "#fff", border: "1px solid rgba(201,168,76,0.15)", boxShadow: "0 2px 12px rgba(26,18,8,0.04)" }}
            >
              {/* Question header */}
              <div className="flex items-center justify-between mb-5">
                <div
                  className="px-3 py-1 rounded-full text-xs font-bold"
                  style={{ background: "linear-gradient(135deg,#C9A84C,#8B6914)", color: "#1A1208", fontFamily: "Cairo,sans-serif" }}
                >
                  سؤال {qi + 1}
                </div>
                {questions.length > 1 && (
                  <button type="button" onClick={() => removeQuestion(qi)}
                    style={{ padding: "4px 12px", borderRadius: 8, border: "1px solid rgba(239,68,68,0.25)", color: "#DC2626", background: "none", fontFamily: "Cairo,sans-serif", fontSize: 12, cursor: "pointer" }}>
                    حذف السؤال
                  </button>
                )}
              </div>

              {/* Question text */}
              <div className="mb-4">
                <label style={{ fontFamily: "Cairo,sans-serif", color: "#4A3F2A", fontSize: 12, marginBottom: 4, display: "block" }}>
                  نص السؤال
                </label>
                <textarea value={q.text ?? ""} onChange={(e) => updateQuestion(qi, "text", e.target.value)}
                  placeholder="اكتب نص السؤال هنا... (اختياري إذا أضفت صورة)"
                  rows={2} style={{ ...fieldStyle, width: "100%", resize: "vertical" }}
                  onFocus={(e) => (e.target.style.borderColor = "rgba(201,168,76,0.6)")}
                  onBlur={(e)  => (e.target.style.borderColor = "rgba(201,168,76,0.25)")} />
              </div>

              {/* Question image */}
              <div className="mb-5">
                <label style={{ fontFamily: "Cairo,sans-serif", color: "#4A3F2A", fontSize: 12, marginBottom: 4, display: "block" }}>
                  🖼️ رابط صورة السؤال (اختياري)
                </label>
                <input value={q.imageUrl ?? ""} onChange={(e) => updateQuestion(qi, "imageUrl", e.target.value)}
                  placeholder="https://..."
                  style={{ ...fieldStyle, width: "100%", direction: "ltr" }}
                  onFocus={(e) => (e.target.style.borderColor = "rgba(201,168,76,0.6)")}
                  onBlur={(e)  => (e.target.style.borderColor = "rgba(201,168,76,0.25)")} />
                {q.imageUrl && (
                  <img src={q.imageUrl} alt="سؤال" className="mt-2 max-h-40 rounded-xl object-contain border"
                    style={{ borderColor: "rgba(201,168,76,0.2)" }}
                    onError={(e) => { (e.target as HTMLImageElement).style.display = "none"; }} />
                )}
              </div>

              {/* Choices */}
              <div>
                <div className="flex items-center justify-between mb-3">
                  <label style={{ fontFamily: "Cairo,sans-serif", color: "#4A3F2A", fontSize: 13, fontWeight: 600 }}>
                    الخيارات {type === "quiz" ? "(اختر الإجابة الصحيحة)" : ""}
                  </label>
                  <button type="button" onClick={() => addChoice(qi)}
                    style={{ padding: "4px 12px", borderRadius: 8, border: "1px solid rgba(201,168,76,0.3)", color: "#8B6914", background: "none", fontFamily: "Cairo,sans-serif", fontSize: 12, cursor: "pointer" }}>
                    ＋ خيار
                  </button>
                </div>

                <div className="space-y-3">
                  {q.choices.map((c, ci) => (
                    <div key={ci} className="flex items-start gap-3">
                      {/* Correct indicator */}
                      {type === "quiz" && (
                        <button type="button" onClick={() => setCorrect(qi, ci)}
                          className="mt-2 flex-shrink-0"
                          style={{
                            width: 22, height: 22, borderRadius: "50%", border: "2px solid",
                            borderColor: c.isCorrect ? "#2D9E6B" : "rgba(201,168,76,0.35)",
                            background: c.isCorrect ? "#2D9E6B" : "transparent",
                            cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center",
                            color: "#fff", fontSize: 12, transition: "all 0.15s",
                          }}
                          title="الإجابة الصحيحة"
                        >
                          {c.isCorrect ? "✓" : ""}
                        </button>
                      )}

                      <div style={{ flex: 1 }}>
                        <input value={c.text ?? ""} onChange={(e) => updateChoice(qi, ci, "text", e.target.value)}
                          placeholder={`الخيار ${ci + 1}`}
                          style={{ ...fieldStyle, width: "100%", borderColor: c.isCorrect ? "rgba(45,158,107,0.4)" : "rgba(201,168,76,0.25)" }}
                          onFocus={(e) => (e.target.style.borderColor = c.isCorrect ? "rgba(45,158,107,0.6)" : "rgba(201,168,76,0.6)")}
                          onBlur={(e)  => (e.target.style.borderColor = c.isCorrect ? "rgba(45,158,107,0.4)" : "rgba(201,168,76,0.25)")} />

                        {/* Choice image */}
                        <input value={c.imageUrl ?? ""} onChange={(e) => updateChoice(qi, ci, "imageUrl", e.target.value)}
                          placeholder="رابط صورة الخيار (اختياري)"
                          style={{ ...fieldStyle, width: "100%", marginTop: 5, fontSize: 12, direction: "ltr" }}
                          onFocus={(e) => (e.target.style.borderColor = "rgba(201,168,76,0.6)")}
                          onBlur={(e)  => (e.target.style.borderColor = "rgba(201,168,76,0.25)")} />
                        {c.imageUrl && (
                          <img src={c.imageUrl} alt="خيار" className="mt-1 max-h-20 rounded-lg object-contain"
                            onError={(e) => { (e.target as HTMLImageElement).style.display = "none"; }} />
                        )}
                      </div>

                      {q.choices.length > 2 && (
                        <button type="button" onClick={() => removeChoice(qi, ci)}
                          className="mt-2 flex-shrink-0"
                          style={{ width: 22, height: 22, borderRadius: "50%", border: "1px solid rgba(239,68,68,0.3)", color: "#DC2626", background: "none", cursor: "pointer", fontSize: 14, display: "flex", alignItems: "center", justifyContent: "center" }}>
                          ×
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>

        {/* Add question + Submit */}
        <div className="flex gap-4 flex-wrap">
          <button type="button" onClick={addQuestion}
            style={{
              padding: "12px 28px", borderRadius: 14, border: "1.5px solid rgba(201,168,76,0.3)",
              background: "rgba(201,168,76,0.06)", color: "#8B6914",
              fontFamily: "Cairo,sans-serif", fontWeight: 600, fontSize: 14, cursor: "pointer",
            }}>
            ＋ إضافة سؤال ({questions.length})
          </button>
          <motion.button type="submit" disabled={isPending}
            whileHover={!isPending ? { y: -2 } : {}} whileTap={!isPending ? { scale: 0.98 } : {}}
            style={{
              padding: "12px 40px", borderRadius: 14, border: "none",
              background: isPending ? "rgba(201,168,76,0.35)" : "linear-gradient(135deg,#C9A84C,#8B6914)",
              boxShadow: isPending ? "none" : "0 6px 20px rgba(201,168,76,0.4)",
              color: "#1A1208", fontFamily: "Cairo,sans-serif", fontWeight: 700, fontSize: 15,
              cursor: isPending ? "not-allowed" : "pointer", transition: "all 0.2s",
            }}>
            {isPending ? "⏳ جارٍ الحفظ..." : `💾 حفظ ${type === "quiz" ? "الاختبار" : "الواجب"} (${questions.length} سؤال)`}
          </motion.button>
        </div>
      </form>
    </div>
  );
}
