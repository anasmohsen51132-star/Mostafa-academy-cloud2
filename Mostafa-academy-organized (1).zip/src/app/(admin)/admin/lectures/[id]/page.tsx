"use client";
// src/app/(admin)/admin/lectures/[id]/page.tsx
import { useState } from "react";
import { useParams } from "next/navigation";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { motion, AnimatePresence } from "framer-motion";
import Link from "next/link";
import { fetchWithAuth } from "@/hooks/useAuth";
import { useToast } from "@/store/uiStore";
import { extractYouTubeId } from "@/lib/utils";
import type { Video, PDF, Quiz, Homework, Course } from "@/types";

type ActiveTab = "videos" | "pdfs" | "quizzes" | "homework" | "settings";

export default function LectureEditPage() {
  const { id }   = useParams<{ id: string }>();
  const toast    = useToast();
  const qc       = useQueryClient();
  const [tab, setTab] = useState<ActiveTab>("videos");

  // Video form state
  const [videoTitle, setVideoTitle] = useState("");
  const [videoUrl,   setVideoUrl]   = useState("");

  // PDF form state
  const [pdfTitle, setPdfTitle] = useState("");
  const [pdfUrl,   setPdfUrl]   = useState("");

  const { data, isLoading } = useQuery({
    queryKey: ["admin-lecture", id],
    queryFn:  () => fetchWithAuth(`/api/lectures/${id}`),
    enabled:  !!id,
  });

  const lecture = data?.data;

  // ── Add video mutation ──
  const addVideo = useMutation({
    mutationFn: () =>
      fetchWithAuth("/api/videos", {
        method: "POST",
        body: JSON.stringify({ lectureId: id, title: videoTitle, youtubeUrl: videoUrl }),
      }),
    onSuccess: (res) => {
      if (res.success) {
        toast.success("✅ تم إضافة الفيديو");
        setVideoTitle(""); setVideoUrl("");
        qc.invalidateQueries({ queryKey: ["admin-lecture", id] });
      } else {
        toast.error(res.error ?? "فشل الإضافة");
      }
    },
  });

  // ── Delete video mutation ──
  const deleteVideo = useMutation({
    mutationFn: (videoId: string) =>
      fetchWithAuth("/api/videos", { method: "DELETE", body: JSON.stringify({ id: videoId }) }),
    onSuccess: () => {
      toast.success("✅ تم حذف الفيديو");
      qc.invalidateQueries({ queryKey: ["admin-lecture", id] });
    },
  });

  // ── Add PDF mutation ──
  const addPDF = useMutation({
    mutationFn: () =>
      fetchWithAuth("/api/pdfs", {
        method: "POST",
        body: JSON.stringify({ lectureId: id, title: pdfTitle, fileUrl: pdfUrl }),
      }),
    onSuccess: (res) => {
      if (res.success) {
        toast.success("✅ تم إضافة الملف");
        setPdfTitle(""); setPdfUrl("");
        qc.invalidateQueries({ queryKey: ["admin-lecture", id] });
      } else {
        toast.error(res.error ?? "فشل الإضافة");
      }
    },
  });

  // ── Delete PDF mutation ──
  const deletePDF = useMutation({
    mutationFn: (pdfId: string) =>
      fetchWithAuth("/api/pdfs", { method: "DELETE", body: JSON.stringify({ id: pdfId }) }),
    onSuccess: () => {
      toast.success("✅ تم حذف الملف");
      qc.invalidateQueries({ queryKey: ["admin-lecture", id] });
    },
  });

  // ── Delete quiz mutation ──
  const deleteQuiz = useMutation({
    mutationFn: (quizId: string) =>
      fetchWithAuth("/api/quizzes", { method: "DELETE", body: JSON.stringify({ id: quizId }) }),
    onSuccess: () => {
      toast.success("✅ تم حذف الاختبار");
      qc.invalidateQueries({ queryKey: ["admin-lecture", id] });
    },
  });

  const TABS: { id: ActiveTab; label: string; icon: string }[] = [
    { id: "videos",   label: "فيديوهات",  icon: "🎥" },
    { id: "pdfs",     label: "ملفات PDF", icon: "📄" },
    { id: "quizzes",  label: "اختبارات",  icon: "📝" },
    { id: "homework", label: "واجبات",    icon: "📋" },
    { id: "settings", label: "الإعدادات", icon: "⚙️" },
  ];

  if (isLoading) {
    return (
      <div style={{ direction: "rtl" }}>
        <div className="skeleton rounded-2xl h-10 w-72 mb-6" />
        <div className="skeleton rounded-2xl h-64" />
      </div>
    );
  }

  if (!lecture) {
    return (
      <div className="text-center py-20" style={{ direction: "rtl" }}>
        <p style={{ fontFamily: "Cairo,sans-serif", color: "#7A6E5A" }}>المحاضرة غير موجودة</p>
        <Link href="/admin/lectures" style={{ color: "#C9A84C", fontFamily: "Cairo,sans-serif", textDecoration: "none" }}>← عودة</Link>
      </div>
    );
  }

  const fieldInput: React.CSSProperties = {
    flex: 1, padding: "10px 13px", borderRadius: 10,
    border: "1.5px solid rgba(201,168,76,0.25)", background: "#FAFAF8",
    color: "#1A1208", fontFamily: "Cairo,sans-serif", fontSize: 13,
    outline: "none", direction: "rtl", transition: "border-color 0.2s",
  };

  return (
    <div style={{ direction: "rtl" }}>
      {/* Header */}
      <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} className="mb-6">
        <div className="flex items-center gap-3 mb-2">
          <Link href="/admin/lectures" style={{ color: "#C9A84C", fontFamily: "Cairo,sans-serif", fontSize: 13, textDecoration: "none" }}>
            ← المحاضرات
          </Link>
        </div>
        <h1 style={{ fontFamily: "Amiri,serif", color: "#1A1208", fontSize: 28, marginBottom: 4 }}>
          {lecture.title}
        </h1>
        {/* Linked courses */}
        <div className="flex flex-wrap gap-2 mt-2">
          {lecture.courses?.map(({ course }: { course: Course }) => (
            <span key={course.id} style={{
              padding: "3px 10px", borderRadius: 8, fontSize: 12,
              background: "rgba(26,107,71,0.08)", color: "#1A6B47",
              border: "1px solid rgba(26,107,71,0.2)", fontFamily: "Cairo,sans-serif",
            }}>
              {course.icon} {course.title}
            </span>
          ))}
        </div>
      </motion.div>

      {/* Tabs */}
      <div className="flex gap-2 mb-6 flex-wrap">
        {TABS.map((t) => (
          <button key={t.id} onClick={() => setTab(t.id)}
            style={{
              padding: "8px 18px", borderRadius: 12, border: "1.5px solid",
              borderColor: tab === t.id ? "#C9A84C" : "rgba(201,168,76,0.25)",
              background: tab === t.id ? "rgba(201,168,76,0.12)" : "#fff",
              color: tab === t.id ? "#8B6914" : "#7A6E5A",
              fontFamily: "Cairo,sans-serif", fontSize: 13,
              fontWeight: tab === t.id ? 700 : 400, cursor: "pointer", transition: "all 0.15s",
            }}
          >
            {t.icon} {t.label}
          </button>
        ))}
      </div>

      <AnimatePresence mode="wait">
        <motion.div key={tab} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }} transition={{ duration: 0.22 }}>

          {/* ═══ VIDEOS TAB ═══ */}
          {tab === "videos" && (
            <div className="space-y-5">
              {/* Add video form */}
              <div className="rounded-2xl p-6" style={{ background: "#fff", border: "1px solid rgba(201,168,76,0.15)", boxShadow: "0 2px 12px rgba(26,18,8,0.04)" }}>
                <h3 style={{ fontFamily: "Amiri,serif", color: "#1A1208", fontSize: 17, marginBottom: 14 }}>إضافة فيديو يوتيوب</h3>
                <div className="flex gap-3 flex-wrap mb-3">
                  <input
                    value={videoTitle} onChange={(e) => setVideoTitle(e.target.value)}
                    placeholder="عنوان الفيديو" style={fieldInput}
                    onFocus={(e) => (e.target.style.borderColor = "rgba(201,168,76,0.6)")}
                    onBlur={(e)  => (e.target.style.borderColor = "rgba(201,168,76,0.25)")}
                  />
                  <input
                    value={videoUrl} onChange={(e) => setVideoUrl(e.target.value)}
                    placeholder="رابط يوتيوب (https://youtube.com/watch?v=...)"
                    style={{ ...fieldInput, direction: "ltr" }}
                    onFocus={(e) => (e.target.style.borderColor = "rgba(201,168,76,0.6)")}
                    onBlur={(e)  => (e.target.style.borderColor = "rgba(201,168,76,0.25)")}
                  />
                  <button
                    onClick={() => {
                      if (!videoTitle.trim()) { toast.error("أدخل عنوان الفيديو"); return; }
                      if (!extractYouTubeId(videoUrl)) { toast.error("رابط يوتيوب غير صحيح"); return; }
                      addVideo.mutate();
                    }}
                    disabled={addVideo.isPending}
                    style={{
                      padding: "10px 22px", borderRadius: 10, border: "none",
                      background: "linear-gradient(135deg,#C9A84C,#8B6914)",
                      color: "#1A1208", fontFamily: "Cairo,sans-serif",
                      fontWeight: 700, fontSize: 13, cursor: "pointer", whiteSpace: "nowrap",
                    }}
                  >
                    {addVideo.isPending ? "⏳..." : "＋ إضافة"}
                  </button>
                </div>
                <p style={{ fontFamily: "Cairo,sans-serif", color: "#7A6E5A", fontSize: 11 }}>
                  ⚠️ الفيديو يُشغَّل داخل المنصة بحماية كاملة — الرابط الأصلي مخفي عن الطلاب
                </p>
              </div>

              {/* Video list */}
              {(lecture.videos?.length ?? 0) === 0 ? (
                <EmptyState icon="🎥" label="لا توجد فيديوهات بعد" />
              ) : (
                <div className="space-y-3">
                  {lecture.videos?.map((v: Video, i: number) => (
                    <motion.div key={v.id} initial={{ opacity: 0, x: 10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.05 }}
                      className="flex items-center gap-4 p-4 rounded-2xl"
                      style={{ background: "#fff", border: "1px solid rgba(201,168,76,0.12)" }}
                    >
                      <img
                        src={`https://img.youtube.com/vi/${Buffer.from(v.youtubeId, "base64").toString()}/mqdefault.jpg`}
                        alt={v.title} className="w-20 h-14 rounded-xl object-cover flex-shrink-0"
                        onError={(e) => { (e.target as HTMLImageElement).style.display = "none"; }}
                      />
                      <div className="flex-1 min-w-0">
                        <p style={{ fontFamily: "Cairo,sans-serif", color: "#1A1208", fontSize: 14, fontWeight: 600, marginBottom: 2 }}>{v.title}</p>
                        <p style={{ fontFamily: "Cairo,sans-serif", color: "#7A6E5A", fontSize: 11 }}>🔒 الرابط محمي</p>
                      </div>
                      <button onClick={() => deleteVideo.mutate(v.id)}
                        style={{ padding: "5px 12px", borderRadius: 8, border: "1px solid rgba(239,68,68,0.25)", color: "#DC2626", background: "none", fontFamily: "Cairo,sans-serif", fontSize: 12, cursor: "pointer" }}>
                        حذف
                      </button>
                    </motion.div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* ═══ PDFs TAB ═══ */}
          {tab === "pdfs" && (
            <div className="space-y-5">
              <div className="rounded-2xl p-6" style={{ background: "#fff", border: "1px solid rgba(201,168,76,0.15)", boxShadow: "0 2px 12px rgba(26,18,8,0.04)" }}>
                <h3 style={{ fontFamily: "Amiri,serif", color: "#1A1208", fontSize: 17, marginBottom: 14 }}>إضافة ملف PDF</h3>
                <div className="flex gap-3 flex-wrap">
                  <input value={pdfTitle} onChange={(e) => setPdfTitle(e.target.value)}
                    placeholder="عنوان الملف" style={fieldInput}
                    onFocus={(e) => (e.target.style.borderColor = "rgba(201,168,76,0.6)")}
                    onBlur={(e)  => (e.target.style.borderColor = "rgba(201,168,76,0.25)")} />
                  <input value={pdfUrl} onChange={(e) => setPdfUrl(e.target.value)}
                    placeholder="رابط الملف (Google Drive, etc.)"
                    style={{ ...fieldInput, direction: "ltr" }}
                    onFocus={(e) => (e.target.style.borderColor = "rgba(201,168,76,0.6)")}
                    onBlur={(e)  => (e.target.style.borderColor = "rgba(201,168,76,0.25)")} />
                  <button onClick={() => { if (!pdfTitle.trim() || !pdfUrl.trim()) { toast.error("أدخل عنوان ورابط الملف"); return; } addPDF.mutate(); }}
                    disabled={addPDF.isPending}
                    style={{ padding: "10px 22px", borderRadius: 10, border: "none", background: "linear-gradient(135deg,#C9A84C,#8B6914)", color: "#1A1208", fontFamily: "Cairo,sans-serif", fontWeight: 700, fontSize: 13, cursor: "pointer", whiteSpace: "nowrap" }}>
                    {addPDF.isPending ? "⏳..." : "＋ إضافة"}
                  </button>
                </div>
              </div>
              {(lecture.pdfs?.length ?? 0) === 0 ? <EmptyState icon="📄" label="لا توجد ملفات بعد" /> : (
                <div className="space-y-3">
                  {lecture.pdfs?.map((p: PDF) => (
                    <div key={p.id} className="flex items-center gap-4 p-4 rounded-2xl"
                      style={{ background: "#fff", border: "1px solid rgba(201,168,76,0.12)" }}>
                      <div className="w-10 h-10 rounded-xl flex items-center justify-center text-xl flex-shrink-0" style={{ background: "rgba(201,168,76,0.1)" }}>📄</div>
                      <div className="flex-1">
                        <p style={{ fontFamily: "Cairo,sans-serif", color: "#1A1208", fontSize: 14, fontWeight: 600 }}>{p.title}</p>
                        <a href={p.fileUrl} target="_blank" rel="noopener noreferrer" style={{ fontFamily: "Cairo,sans-serif", color: "#C9A84C", fontSize: 11, textDecoration: "none" }}>فتح الرابط ↗</a>
                      </div>
                      <button onClick={() => deletePDF.mutate(p.id)}
                        style={{ padding: "5px 12px", borderRadius: 8, border: "1px solid rgba(239,68,68,0.25)", color: "#DC2626", background: "none", fontFamily: "Cairo,sans-serif", fontSize: 12, cursor: "pointer" }}>
                        حذف
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* ═══ QUIZZES TAB ═══ */}
          {tab === "quizzes" && (
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 style={{ fontFamily: "Amiri,serif", color: "#1A1208", fontSize: 20 }}>الاختبارات</h3>
                <Link href={`/admin/quiz-builder?lectureId=${id}&type=quiz`}
                  style={{ padding: "9px 22px", borderRadius: 12, background: "linear-gradient(135deg,#C9A84C,#8B6914)", color: "#1A1208", fontFamily: "Cairo,sans-serif", fontWeight: 700, fontSize: 13, textDecoration: "none" }}>
                  ＋ اختبار جديد
                </Link>
              </div>
              {(lecture.quizzes?.length ?? 0) === 0 ? <EmptyState icon="📝" label="لا توجد اختبارات — أضف اختباراً جديداً" /> : (
                <div className="space-y-3">
                  {lecture.quizzes?.map((q: Quiz) => (
                    <div key={q.id} className="flex items-center gap-4 p-5 rounded-2xl"
                      style={{ background: "#fff", border: "1px solid rgba(201,168,76,0.12)" }}>
                      <div className="w-10 h-10 rounded-xl flex items-center justify-center text-xl flex-shrink-0" style={{ background: "rgba(201,168,76,0.1)" }}>📝</div>
                      <div className="flex-1">
                        <p style={{ fontFamily: "Cairo,sans-serif", color: "#1A1208", fontSize: 14, fontWeight: 600 }}>{q.title}</p>
                        <p style={{ fontFamily: "Cairo,sans-serif", color: "#7A6E5A", fontSize: 12 }}>
                          {q.questions?.length ?? q._count?.questions ?? 0} سؤال
                          {q.timeLimit ? ` • ${q.timeLimit} دقيقة` : ""}
                        </p>
                      </div>
                      <button onClick={() => deleteQuiz.mutate(q.id)}
                        style={{ padding: "5px 12px", borderRadius: 8, border: "1px solid rgba(239,68,68,0.25)", color: "#DC2626", background: "none", fontFamily: "Cairo,sans-serif", fontSize: 12, cursor: "pointer" }}>
                        حذف
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* ═══ HOMEWORK TAB ═══ */}
          {tab === "homework" && (
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 style={{ fontFamily: "Amiri,serif", color: "#1A1208", fontSize: 20 }}>الواجبات</h3>
                <Link href={`/admin/quiz-builder?lectureId=${id}&type=homework`}
                  style={{ padding: "9px 22px", borderRadius: 12, background: "linear-gradient(135deg,#C9A84C,#8B6914)", color: "#1A1208", fontFamily: "Cairo,sans-serif", fontWeight: 700, fontSize: 13, textDecoration: "none" }}>
                  ＋ واجب جديد
                </Link>
              </div>
              {(lecture.homework?.length ?? 0) === 0 ? <EmptyState icon="📋" label="لا توجد واجبات — أضف واجباً جديداً" /> : (
                <div className="space-y-3">
                  {lecture.homework?.map((hw: Homework) => (
                    <div key={hw.id} className="flex items-center gap-4 p-5 rounded-2xl"
                      style={{ background: "#fff", border: "1px solid rgba(201,168,76,0.12)" }}>
                      <div className="w-10 h-10 rounded-xl flex items-center justify-center text-xl flex-shrink-0" style={{ background: "rgba(201,168,76,0.1)" }}>📋</div>
                      <div className="flex-1">
                        <p style={{ fontFamily: "Cairo,sans-serif", color: "#1A1208", fontSize: 14, fontWeight: 600 }}>{hw.title}</p>
                        <p style={{ fontFamily: "Cairo,sans-serif", color: "#7A6E5A", fontSize: 12 }}>
                          {hw.questions?.length ?? hw._count?.questions ?? 0} سؤال
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* ═══ SETTINGS TAB ═══ */}
          {tab === "settings" && (
            <LectureSettings lecture={lecture} lectureId={id} qc={qc} toast={toast} />
          )}

        </motion.div>
      </AnimatePresence>
    </div>
  );
}

function LectureSettings({ lecture, lectureId, qc, toast }: {
  lecture: { title: string; description?: string | null; courses?: { course: Course }[] };
  lectureId: string;
  qc: ReturnType<typeof useQueryClient>;
  toast: ReturnType<typeof useToast>;
}) {
  const [title,       setTitle]       = useState(lecture.title);
  const [description, setDescription] = useState(lecture.description ?? "");

  const mutation = useMutation({
    mutationFn: () => fetchWithAuth(`/api/lectures/${lectureId}`, {
      method: "PUT",
      body: JSON.stringify({ title, description, courseIds: lecture.courses?.map((c) => c.course.id) ?? [] }),
    }),
    onSuccess: (res) => {
      if (res.success) { toast.success("✅ تم التحديث"); qc.invalidateQueries({ queryKey: ["admin-lecture", lectureId] }); }
      else toast.error(res.error ?? "فشل التحديث");
    },
  });

  const fieldInput: React.CSSProperties = {
    width: "100%", padding: "12px 14px", borderRadius: 12,
    border: "1.5px solid rgba(201,168,76,0.25)", background: "#FAFAF8",
    color: "#1A1208", fontFamily: "Cairo,sans-serif", fontSize: 14,
    outline: "none", direction: "rtl", transition: "border-color 0.2s",
  };

  return (
    <div className="rounded-2xl p-6 max-w-lg" style={{ background: "#fff", border: "1px solid rgba(201,168,76,0.15)", boxShadow: "0 2px 12px rgba(26,18,8,0.04)" }}>
      <h3 style={{ fontFamily: "Amiri,serif", color: "#1A1208", fontSize: 18, marginBottom: 16 }}>إعدادات المحاضرة</h3>
      <div style={{ marginBottom: 14 }}>
        <label style={{ fontFamily: "Cairo,sans-serif", color: "#4A3F2A", fontSize: 13, marginBottom: 5, display: "block", fontWeight: 600 }}>العنوان</label>
        <input value={title} onChange={(e) => setTitle(e.target.value)} style={fieldInput}
          onFocus={(e) => (e.target.style.borderColor = "rgba(201,168,76,0.6)")}
          onBlur={(e)  => (e.target.style.borderColor = "rgba(201,168,76,0.25)")} />
      </div>
      <div style={{ marginBottom: 20 }}>
        <label style={{ fontFamily: "Cairo,sans-serif", color: "#4A3F2A", fontSize: 13, marginBottom: 5, display: "block", fontWeight: 600 }}>الوصف</label>
        <textarea value={description} onChange={(e) => setDescription(e.target.value)} rows={3}
          style={{ ...fieldInput, resize: "vertical" }}
          onFocus={(e) => (e.target.style.borderColor = "rgba(201,168,76,0.6)")}
          onBlur={(e)  => (e.target.style.borderColor = "rgba(201,168,76,0.25)")} />
      </div>
      <button onClick={() => mutation.mutate()} disabled={mutation.isPending}
        style={{ padding: "12px 28px", borderRadius: 12, border: "none", background: "linear-gradient(135deg,#C9A84C,#8B6914)", color: "#1A1208", fontFamily: "Cairo,sans-serif", fontWeight: 700, fontSize: 14, cursor: "pointer" }}>
        {mutation.isPending ? "⏳..." : "💾 حفظ"}
      </button>
    </div>
  );
}

function EmptyState({ icon, label }: { icon: string; label: string }) {
  return (
    <div className="text-center py-14 rounded-2xl" style={{ background: "#fff", border: "1px solid rgba(201,168,76,0.12)" }}>
      <div style={{ fontSize: 44, marginBottom: 10 }}>{icon}</div>
      <p style={{ fontFamily: "Cairo,sans-serif", color: "#7A6E5A", fontSize: 14 }}>{label}</p>
    </div>
  );
}
