"use client";
// src/app/(admin)/layout.tsx
import { useEffect } from "react";
import { useRouter } from "next/navigation";
import { Sidebar } from "@/components/layout/Sidebar";
import { ToastContainer } from "@/components/ui/Toast";
import { useAuth } from "@/hooks/useAuth";
import type { SidebarItem } from "@/components/layout/Sidebar";

const ADMIN_NAV: SidebarItem[] = [
  { id: "overview",    label: "لوحة التحكم",    icon: "📊", href: "/admin",                section: "الرئيسية" },
  { id: "courses",     label: "الكورسات",        icon: "📚", href: "/admin/courses",        section: "المحتوى" },
  { id: "lectures",    label: "المحاضرات",       icon: "🎬", href: "/admin/lectures",       section: "المحتوى" },
  { id: "quiz",        label: "منشئ الاختبارات", icon: "📝", href: "/admin/quiz-builder",   section: "المحتوى" },
  { id: "codes",       label: "كودات الوصول",    icon: "🎟️", href: "/admin/codes",          section: "الطلاب" },
  { id: "students",    label: "الطلاب",          icon: "👥", href: "/admin/students",       section: "الطلاب" },
];

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  const { user, isAuthenticated, isAdmin, logout } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (!isAuthenticated) { router.replace("/login"); return; }
    if (!isAdmin)          { router.replace("/dashboard"); }
  }, [isAuthenticated, isAdmin, router]);

  if (!isAuthenticated || !user || !isAdmin) return null;

  return (
    <div className="min-h-screen" style={{ background: "#F5F1E8", direction: "rtl" }}>
      <ToastContainer />
      <Sidebar
        items={ADMIN_NAV}
        brandSub={user.role === "OWNER" ? "👑 لوحة المالك" : "🔵 لوحة الأدمن"}
        onLogout={logout}
        userName={user.name}
        userAvatar={user.avatar ?? user.name.charAt(0)}
      />
      <main className="min-h-screen" style={{ marginRight: 256, padding: "28px 32px" }}>
        {children}
      </main>
    </div>
  );
}
