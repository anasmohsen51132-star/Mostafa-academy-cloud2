"use client";
// src/app/(student)/layout.tsx
import { useEffect } from "react";
import { useRouter } from "next/navigation";
import { Sidebar } from "@/components/layout/Sidebar";
import { ToastContainer } from "@/components/ui/Toast";
import { useAuth } from "@/hooks/useAuth";
import type { SidebarItem } from "@/components/layout/Sidebar";

const STUDENT_NAV: SidebarItem[] = [
  { id: "dashboard",  label: "لوحة التحكم",  icon: "🏠", href: "/dashboard" },
  { id: "courses",    label: "الكورسات",      icon: "📚", href: "/courses" },
  { id: "my-courses", label: "كورساتي",       icon: "🎓", href: "/my-courses" },
  { id: "redeem",     label: "استخدام كود",   icon: "🎟️", href: "/redeem" },
  { id: "profile",    label: "الملف الشخصي",  icon: "👤", href: "/profile" },
];

export default function StudentLayout({ children }: { children: React.ReactNode }) {
  const { user, isAuthenticated, logout } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (!isAuthenticated) {
      router.replace("/login");
    }
  }, [isAuthenticated, router]);

  if (!isAuthenticated || !user) return null;

  return (
    <div className="min-h-screen" style={{ background: "#FAF7F0", direction: "rtl" }}>
      <ToastContainer />
      <Sidebar
        items={STUDENT_NAV}
        brandSub="منصة الطالب"
        onLogout={logout}
        userName={user.name}
        userAvatar={user.avatar ?? user.name.charAt(0)}
      />
      {/* Main content — offset for sidebar (w-64 = 256px) */}
      <main
        className="min-h-screen"
        style={{ marginRight: 256, padding: "28px 32px" }}
      >
        {children}
      </main>
    </div>
  );
}
