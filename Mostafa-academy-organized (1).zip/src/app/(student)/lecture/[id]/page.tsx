"use client";
// src/app/(student)/lecture/[id]/page.tsx
import { useState } from "react";
import { useParams } from "next/navigation";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { motion, AnimatePresence } from "framer-motion";
import { fetchWithAuth } from "@/hooks/useAuth";
import { VideoPlayer } from "@/components/courses/VideoPlayer";
import { useToast } from "@/store/uiStore";
import type { Video, PDF, Quiz, Question } from "@/types";

type Tab = "videos" | "pdfs" | "quiz" | "homework";

export default function LecturePage() {
  const { id } = useParams<{ id: string }>();
  const toast = useToast();
  const qc = useQueryClient();
  const [activeTab, setActiveTab] = useState<Tab>("videos");
  const [selectedQuizId, setSelectedQuizId] = useState<string | null>(null);
  const [quizAnswers, setQuizAnswers] = useState<Record<string, string>>({});
  const [quizResult, setQuizResult] = useState<{ score: number; total: number; percentage: number; passed: boolean } | null>(null);

  const { data, isLoading } = useQuery({
    queryKey: ["lecture", id],
    queryFn: () => fetchWithAuth(`/api/lectures/${id}`),
    enabled: !!id,
  });

  const lecture = data?.data;

  const submitQuizMutation = useMutation({
    mutationFn: ({ quizId, answers }: { quizId: string; answers: Record<string, string> }) =>
      fetchWithAuth(`/api/quizzes/${quizId}/submit`, { method: "POST", body: JSON.stringify({ answers }) }),
    onSuccess: (res) => {
      if (res.success) {
        setQuizResult(res.data);
        toast.success(`✅ تم تسليم الاختبار — ${res.data.percentage}٪`);
        qc.invalidateQueries({ queryKey: ["lecture", id] });
      } else {
        toast.error(res.error ?? "خطأ في التسليم");
      }
    },
  });

  const tabs: { id: Tab; label: string; icon: string; count: number }[] = [
    { id: "videos",   label: "فيديوهات", icon: "🎥", count: lecture?.videos?.length ?? 0 },
    { id: "pdfs",     label: "ملفات",    icon: "📄", count: lecture?.pdfs?.length ?? 0 },
    { id: "quiz",     label: "اختبارات", icon: "📝", count: lecture?.quizzes?.length ?? 0 },
    { id: "homework", label: "واجبات",   icon: "📋", count: lecture?.homework?.length ?? 0 },
  ].filter((t) => t.count > 0);

  if (isLoading) {
    return (
      <div style={{ direction: "rtl" }}>
        <div className="skeleton rounded-3xl h-32 mb-6" />
        <div className="skeleton rounded-2xl h-64" />
      </div>
    );
  }

  if (!lecture) {
    return (
      <div className="text-center py-20" style={{ direction: "rtl" }}>
        <div style={{ fontSize: 56, marginBottom: 16 }}>⚠️</div>
        <h3 style={{ fontFamily: "Amiri,serif", color: "#1A1208", fontSize: 24 }}>المحاضرة غير موجودة</h3>
      </div>
    );
  }

  return (
    <div style={{ direction: "rtl" }}>
      {/* Lecture header */}
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-6"
      >
        <h1 style={{ fontFamily: "Amiri,serif", color: "#1A1208", fontSize: 30, marginBottom: 6 }}>
          {lecture.title}
        </h1>
        {lecture.description && (
          <p style={{ fontFamily: "Cairo,sans-serif", color: "#7A6E5A", fontSize: 15, lineHeight: 1.75 }}>
            {lecture.description}
          </p>
        )}
      </motion.div>

      {/* Tabs */}
      {tabs.length > 1 && (
        <div className="flex gap-2 mb-6 flex-wrap">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => { setActiveTab(tab.id); setSelectedQuizId(null); setQuizResult(null); }}
              style={{
                padding: "8px 18px",
                borderRadius: 12,
                border: "1.5px solid",
                borderColor: activeTab === tab.id ? "#C9A84C" : "rgba(201,168,76,0.25)",
                background: activeTab === tab.id ? "rgba(201,168,76,0.12)" : "#fff",
                color: activeTab === tab.id ? "#8B6914" : "#7A6E5A",
                fontFamily: "Cairo,sans-serif",
                fontSize: 13,
                fontWeight: activeTab === tab.id ? 700 : 400,
                cursor: "pointer",
                transition: "all 0.15s",
              }}
            >
              {tab.icon} {tab.label} ({tab.count})
            </button>
          ))}
        </div>
      )}

      <AnimatePresence mode="wait">
        <motion.div
          key={activeTab}
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -8 }}
          transition={{ duration: 0.25 }}
        >

          {/* ── VIDEOS TAB ── */}
          {(activeTab === "videos" || tabs.length === 0) && (
            <div className="space-y-6">
              {lecture.videos?.length ? (
                lecture.videos.map((video: Video) => (
                  <div key={video.id}>
                    <h3 style={{ fontFamily: "Cairo,sans-serif", color: "#1A1208", fontSize: 15, fontWeight: 700, marginBottom: 10 }}>
                      🎥 {video.title}
                    </h3>
                    <VideoPlayer youtubeId={video.youtubeId} title={video.title} />
                  </div>
                ))
              ) : (
                <EmptyTab label="لا توجد فيديوهات" icon="🎥" />
              )}
            </div>
          )}

          {/* ── PDFs TAB ── */}
          {activeTab === "pdfs" && (
            <div className="space-y-3">
              {lecture.pdfs?.map((pdf: PDF) => (
                <motion.a
                  key={pdf.id}
                  href={pdf.fileUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  whileHover={{ x: -4 }}
                  className="flex items-center gap-4 p-5 rounded-2xl"
                  style={{
                    background: "#fff",
                    border: "1px solid rgba(201,168,76,0.2)",
                    boxShadow: "0 2px 8px rgba(26,18,8,0.04)",
                    textDecoration: "none",
                    display: "flex",
                  }}
                >
                  <div
                    className="w-12 h-12 rounded-xl flex items-center justify-center text-2xl flex-shrink-0"
                    style={{ background: "rgba(201,168,76,0.12)" }}
                  >
                    📄
                  </div>
                  <div>
                    <p style={{ fontFamily: "Cairo,sans-serif", color: "#1A1208", fontSize: 15, fontWeight: 600 }}>
                      {pdf.title}
                    </p>
                    <p style={{ fontFamily: "Cairo,sans-serif", color: "#C9A84C", fontSize: 12, marginTop: 2 }}>
                      اضغط لفتح الملف ↗
                    </p>
                  </div>
                </motion.a>
              ))}
            </div>
          )}

          {/* ── QUIZ TAB ── */}
          {activeTab === "quiz" && (
            <div>
              {!selectedQuizId ? (
                <div className="space-y-3">
                  {lecture.quizzes?.map((quiz: Quiz) => (
                    <motion.div
                      key={quiz.id}
                      whileHover={{ x: -4 }}
                      className="flex items-center justify-between p-5 rounded-2xl cursor-pointer"
                      style={{ background: "#fff", border: "1px solid rgba(201,168,76,0.2)", boxShadow: "0 2px 8px rgba(26,18,8,0.04)" }}
                      onClick={() => { setSelectedQuizId(quiz.id); setQuizAnswers({}); setQuizResult(null); }}
                    >
                      <div className="flex items-center gap-4">
                        <div className="w-12 h-12 rounded-xl flex items-center justify-center text-2xl" style={{ background: "rgba(201,168,76,0.12)" }}>📝</div>
                        <div>
                          <p style={{ fontFamily: "Cairo,sans-serif", color: "#1A1208", fontSize: 15, fontWeight: 600 }}>{quiz.title}</p>
                          <p style={{ fontFamily: "Cairo,sans-serif", color: "#7A6E5A", fontSize: 12, marginTop: 2 }}>
                            {quiz._count?.questions ?? quiz.questions?.length ?? 0} سؤال
                            {quiz.timeLimit ? ` — ${quiz.timeLimit} دقيقة` : ""}
                          </p>
                        </div>
                      </div>
                      <span style={{ color: "#C9A84C", fontSize: 20 }}>←</span>
                    </motion.div>
                  ))}
                </div>
              ) : (
                <QuizPlayer
                  quiz={lecture.quizzes?.find((q: Quiz) => q.id === selectedQuizId)!}
                  answers={quizAnswers}
                  onAnswer={(qId, cId) => setQuizAnswers((a) => ({ ...a, [qId]: cId }))}
                  onSubmit={() => submitQuizMutation.mutate({ quizId: selectedQuizId, answers: quizAnswers })}
                  onBack={() => { setSelectedQuizId(null); setQuizResult(null); }}
                  result={quizResult}
                  isSubmitting={submitQuizMutation.isPending}
                />
              )}
            </div>
          )}

          {/* ── HOMEWORK TAB ── */}
          {activeTab === "homework" && (
            <div className="space-y-3">
              {lecture.homework?.map((hw: { id: string; title: string; questions?: Question[] }) => (
                <div key={hw.id} className="p-5 rounded-2xl" style={{ background: "#fff", border: "1px solid rgba(201,168,76,0.2)" }}>
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-10 h-10 rounded-xl flex items-center justify-center text-xl" style={{ background: "rgba(201,168,76,0.12)" }}>📋</div>
                    <h3 style={{ fontFamily: "Cairo,sans-serif", color: "#1A1208", fontSize: 15, fontWeight: 700 }}>{hw.title}</h3>
                  </div>
                  <p style={{ fontFamily: "Cairo,sans-serif", color: "#7A6E5A", fontSize: 13 }}>
                    {hw.questions?.length ?? 0} سؤال — يُسلَّم للمعلم مباشرة
                  </p>
                </div>
              ))}
            </div>
          )}

        </motion.div>
      </AnimatePresence>
    </div>
  );
}

// ── Quiz Player sub-component ──
function QuizPlayer({
  quiz, answers, onAnswer, onSubmit, onBack, result, isSubmitting,
}: {
  quiz: Quiz;
  answers: Record<string, string>;
  onAnswer: (qId: string, cId: string) => void;
  onSubmit: () => void;
  onBack: () => void;
  result: { score: number; total: number; percentage: number; passed: boolean } | null;
  isSubmitting: boolean;
}) {
  const answered = Object.keys(answers).length;
  const total = quiz.questions?.length ?? 0;

  if (result) {
    return (
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="text-center py-12"
        style={{ background: "#fff", borderRadius: 24, border: "1px solid rgba(201,168,76,0.2)", padding: 40 }}
      >
        <div style={{ fontSize: 72, marginBottom: 16 }}>{result.passed ? "🎉" : "💪"}</div>
        <h2 style={{ fontFamily: "Amiri,serif", color: "#1A1208", fontSize: 32, marginBottom: 8 }}>
          {result.passed ? "أحسنت!" : "حاول مرة أخرى"}
        </h2>
        <div style={{ fontFamily: "Amiri,serif", color: "#C9A84C", fontSize: 56, fontWeight: 700, marginBottom: 4 }}>
          {result.percentage}٪
        </div>
        <p style={{ fontFamily: "Cairo,sans-serif", color: "#7A6E5A", fontSize: 15, marginBottom: 24 }}>
          {result.score} / {result.total} إجابة صحيحة
        </p>
        <button
          onClick={onBack}
          style={{
            padding: "12px 32px", borderRadius: 14,
            background: "linear-gradient(135deg,#C9A84C,#8B6914)",
            color: "#1A1208", fontFamily: "Cairo,sans-serif",
            fontWeight: 700, fontSize: 15, border: "none", cursor: "pointer",
          }}
        >
          العودة للاختبارات
        </button>
      </motion.div>
    );
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <button onClick={onBack} style={{ fontFamily: "Cairo,sans-serif", color: "#C9A84C", fontSize: 13, background: "none", border: "none", cursor: "pointer" }}>
          ← عودة
        </button>
        <span style={{ fontFamily: "Cairo,sans-serif", color: "#7A6E5A", fontSize: 13 }}>
          {answered} / {total} مجاب
        </span>
      </div>

      {/* Progress bar */}
      <div className="h-2 rounded-full mb-8" style={{ background: "rgba(201,168,76,0.15)" }}>
        <motion.div
          className="h-full rounded-full"
          style={{ background: "linear-gradient(90deg,#C9A84C,#8B6914)" }}
          animate={{ width: `${total ? (answered / total) * 100 : 0}%` }}
          transition={{ duration: 0.3 }}
        />
      </div>

      <div className="space-y-6">
        {quiz.questions?.map((q: Question, qi: number) => (
          <div
            key={q.id}
            className="p-6 rounded-2xl"
            style={{ background: "#fff", border: "1px solid rgba(201,168,76,0.15)", boxShadow: "0 2px 12px rgba(26,18,8,0.04)" }}
          >
            <p style={{ fontFamily: "Cairo,sans-serif", color: "#1A1208", fontSize: 15, fontWeight: 600, marginBottom: 12 }}>
              {qi + 1}. {q.text}
            </p>
            {q.imageUrl && (
              <img
                src={q.imageUrl} alt="سؤال"
                className="rounded-xl mb-4 max-h-48 object-contain"
                draggable={false}
                onContextMenu={(e) => e.preventDefault()}
              />
            )}
            <div className="space-y-2">
              {q.choices?.map((c) => (
                <button
                  key={c.id}
                  onClick={() => onAnswer(q.id, c.id)}
                  style={{
                    width: "100%",
                    padding: "12px 16px",
                    borderRadius: 12,
                    border: "1.5px solid",
                    borderColor: answers[q.id] === c.id ? "#C9A84C" : "rgba(201,168,76,0.2)",
                    background: answers[q.id] === c.id ? "rgba(201,168,76,0.12)" : "rgba(250,247,240,0.5)",
                    color: "#1A1208",
                    fontFamily: "Cairo,sans-serif",
                    fontSize: 14,
                    textAlign: "right",
                    cursor: "pointer",
                    transition: "all 0.15s",
                    display: "flex",
                    alignItems: "center",
                    gap: 10,
                  }}
                >
                  <span style={{
                    width: 20, height: 20, borderRadius: "50%", flexShrink: 0,
                    border: `2px solid ${answers[q.id] === c.id ? "#C9A84C" : "rgba(201,168,76,0.35)"}`,
                    background: answers[q.id] === c.id ? "#C9A84C" : "transparent",
                    transition: "all 0.15s",
                  }} />
                  {c.text}
                  {c.imageUrl && <img src={c.imageUrl} alt="" className="h-8 object-contain rounded" />}
                </button>
              ))}
            </div>
          </div>
        ))}
      </div>

      <div className="mt-8 flex justify-center">
        <button
          onClick={onSubmit}
          disabled={answered < total || isSubmitting}
          style={{
            padding: "14px 48px", borderRadius: 16,
            background: answered < total ? "rgba(201,168,76,0.3)" : "linear-gradient(135deg,#C9A84C,#8B6914)",
            color: "#1A1208", fontFamily: "Cairo,sans-serif",
            fontWeight: 700, fontSize: 16, border: "none",
            cursor: answered < total ? "not-allowed" : "pointer",
            boxShadow: answered >= total ? "0 6px 20px rgba(201,168,76,0.4)" : "none",
            transition: "all 0.2s",
          }}
        >
          {isSubmitting ? "⏳ جارٍ التسليم..." : answered < total ? `أجب على ${total - answered} سؤال متبقي` : "✅ تسليم الاختبار"}
        </button>
      </div>
    </div>
  );
}

function EmptyTab({ label, icon }: { label: string; icon: string }) {
  return (
    <div className="text-center py-16" style={{ background: "#fff", borderRadius: 20, border: "1px solid rgba(201,168,76,0.15)" }}>
      <div style={{ fontSize: 48, marginBottom: 12 }}>{icon}</div>
      <p style={{ fontFamily: "Cairo,sans-serif", color: "#7A6E5A", fontSize: 15 }}>{label}</p>
    </div>
  );
}
