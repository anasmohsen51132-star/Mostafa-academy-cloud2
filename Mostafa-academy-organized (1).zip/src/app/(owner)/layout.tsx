"use client";
// src/app/(owner)/layout.tsx
import { useEffect } from "react";
import { useRouter } from "next/navigation";
import { Sidebar } from "@/components/layout/Sidebar";
import { ToastContainer } from "@/components/ui/Toast";
import { useAuth } from "@/hooks/useAuth";
import type { SidebarItem } from "@/components/layout/Sidebar";

const OWNER_NAV: SidebarItem[] = [
  { id: "overview",   label: "لوحة المالك",      icon: "👑", href: "/owner",              section: "الرئيسية" },
  { id: "courses",    label: "الكورسات",          icon: "📚", href: "/admin/courses",      section: "الإدارة" },
  { id: "lectures",   label: "المحاضرات",         icon: "🎬", href: "/admin/lectures",     section: "الإدارة" },
  { id: "codes",      label: "كودات الوصول",      icon: "🎟️", href: "/admin/codes",        section: "الإدارة" },
  { id: "students",   label: "الطلاب",            icon: "👥", href: "/admin/students",     section: "الإدارة" },
  { id: "admins",     label: "المشرفون",          icon: "🔵", href: "/owner/admins",       section: "المالك" },
  { id: "customize",  label: "تخصيص المنصة",     icon: "🎨", href: "/owner/customize",    section: "المالك" },
  { id: "settings",   label: "الإعدادات",         icon: "⚙️", href: "/owner/settings",     section: "المالك" },
];

export default function OwnerLayout({ children }: { children: React.ReactNode }) {
  const { user, isAuthenticated, isOwner, logout } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (!isAuthenticated) { router.replace("/login"); return; }
    if (!isOwner)          { router.replace("/dashboard"); }
  }, [isAuthenticated, isOwner, router]);

  if (!isAuthenticated || !user || !isOwner) return null;

  return (
    <div className="min-h-screen" style={{ background: "#F5F1E8", direction: "rtl" }}>
      <ToastContainer />
      <Sidebar
        items={OWNER_NAV}
        brandSub="👑 لوحة المالك"
        onLogout={logout}
        userName={user.name}
        userAvatar={user.avatar ?? user.name.charAt(0)}
      />
      <main className="min-h-screen" style={{ marginRight: 256, padding: "28px 32px" }}>
        {children}
      </main>
    </div>
  );
}
