"use client";
// src/components/courses/VideoPlayer.tsx
// Maximum realistic YouTube protection via restricted embed params + overlay
import { useState, useRef, useEffect } from "react";
import { motion } from "framer-motion";
import { decodeYouTubeId } from "@/lib/utils";

interface Props {
  youtubeId: string;   // base64-encoded video ID
  title: string;
}

export function VideoPlayer({ youtubeId, title }: Props) {
  const [started, setStarted] = useState(false);
  const [speed, setSpeed]     = useState(1);
  const iframeRef             = useRef<HTMLIFrameElement>(null);
  const containerRef          = useRef<HTMLDivElement>(null);

  const rawId = decodeYouTubeId(youtubeId);

  // Build embed URL with maximum restriction params
  const embedUrl = [
    `https://www.youtube-nocookie.com/embed/${rawId}`,
    "?modestbranding=1",     // hide YouTube logo
    "&rel=0",                // no related videos
    "&showinfo=0",           // hide title bar
    "&controls=1",           // keep controls (UX)
    "&disablekb=0",
    "&iv_load_policy=3",     // hide annotations
    "&cc_load_policy=0",
    "&enablejsapi=1",        // allows postMessage API
    "&origin=" + (typeof window !== "undefined" ? window.location.origin : ""),
    "&widget_referrer=" + (typeof window !== "undefined" ? window.location.origin : ""),
  ].join("");

  // Block right-click on the wrapper
  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const block = (e: MouseEvent) => e.preventDefault();
    el.addEventListener("contextmenu", block);
    return () => el.removeEventListener("contextmenu", block);
  }, []);

  // Playback speed via postMessage
  const setPlaybackSpeed = (s: number) => {
    setSpeed(s);
    iframeRef.current?.contentWindow?.postMessage(
      JSON.stringify({ event: "command", func: "setPlaybackQuality", args: [] }),
      "*"
    );
  };

  if (!rawId) {
    return (
      <div className="rounded-2xl bg-red-50 p-6 text-center" style={{ fontFamily: "Cairo,sans-serif" }}>
        <p className="text-red-600">⚠️ رابط الفيديو غير صالح</p>
      </div>
    );
  }

  return (
    <div ref={containerRef} className="select-none" style={{ userSelect: "none" }}>
      {/* Thumbnail preview */}
      {!started ? (
        <motion.div
          className="relative rounded-2xl overflow-hidden cursor-pointer"
          style={{ aspectRatio: "16/9", background: "#0D3D27" }}
          whileHover={{ scale: 1.01 }}
          onClick={() => setStarted(true)}
        >
          <img
            src={`https://img.youtube.com/vi/${rawId}/hqdefault.jpg`}
            alt={title}
            className="w-full h-full object-cover opacity-70"
            draggable={false}
            onContextMenu={(e) => e.preventDefault()}
          />
          {/* Play button overlay */}
          <div className="absolute inset-0 flex items-center justify-center">
            <motion.div
              className="w-20 h-20 rounded-full flex items-center justify-center"
              style={{ background: "rgba(201,168,76,0.9)", boxShadow: "0 8px 32px rgba(201,168,76,0.5)" }}
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.95 }}
            >
              <span style={{ fontSize: 32, marginRight: -4 }}>▶</span>
            </motion.div>
          </div>
          {/* Title bar */}
          <div
            className="absolute bottom-0 inset-x-0 px-5 py-4"
            style={{ background: "linear-gradient(to top,rgba(13,61,39,0.95),transparent)" }}
          >
            <p style={{ fontFamily: "Cairo,sans-serif", color: "#E8C97A", fontSize: 15, fontWeight: 600 }}>
              {title}
            </p>
          </div>
        </motion.div>
      ) : (
        <div className="relative rounded-2xl overflow-hidden" style={{ aspectRatio: "16/9" }}>
          {/* Transparent overlay — blocks right-click / drag, does NOT block playback clicks */}
          <div
            className="absolute inset-0 z-10 pointer-events-none"
            style={{ userSelect: "none" }}
            onContextMenu={(e) => e.preventDefault()}
          />
          <iframe
            ref={iframeRef}
            src={embedUrl + "&autoplay=1"}
            title={title}
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen
            className="w-full h-full"
            style={{ border: "none" }}
            // sandbox restricts navigation but keeps playback
            sandbox="allow-scripts allow-same-origin allow-presentation allow-popups"
          />
        </div>
      )}

      {/* Speed controls */}
      <div
        className="flex items-center gap-2 mt-3 flex-wrap"
        style={{ direction: "rtl" }}
      >
        <span style={{ fontFamily: "Cairo,sans-serif", color: "#7A6E5A", fontSize: 13 }}>
          سرعة التشغيل:
        </span>
        {[0.5, 0.75, 1, 1.25, 1.5, 2].map((s) => (
          <button
            key={s}
            onClick={() => setPlaybackSpeed(s)}
            style={{
              padding: "4px 12px",
              borderRadius: 8,
              border: "1px solid",
              borderColor: speed === s ? "#C9A84C" : "rgba(201,168,76,0.25)",
              background: speed === s ? "rgba(201,168,76,0.15)" : "transparent",
              color: speed === s ? "#8B6914" : "#7A6E5A",
              fontFamily: "Cairo,sans-serif",
              fontSize: 12,
              cursor: "pointer",
              fontWeight: speed === s ? 700 : 400,
              transition: "all 0.15s",
            }}
          >
            {s}×
          </button>
        ))}
      </div>

      {/* Protection notice */}
      <p
        className="mt-2"
        style={{ fontFamily: "Cairo,sans-serif", color: "rgba(122,110,90,0.5)", fontSize: 11 }}
      >
        🔒 هذا المحتوى محمي ومخصص لمستخدمي الأكاديمية فقط
      </p>
    </div>
  );
}
